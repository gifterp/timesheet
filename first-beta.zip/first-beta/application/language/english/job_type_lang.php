<?php
$lang['job_type_name']                        = 'Job type';
$lang['job_type_sect_title']                  = 'Job Type List';
$lang['job_type_list_title']                  = 'Job type list';
$lang['job_type_add_btn_text']                = 'Add Job Type';
$lang['job_type_fm_name_lbl']              	 = 'Name';
$lang['job_type_fm_name_ph']  				 	 = 'Add Name';
$lang['job_type_tbl_hdr_name']   			 	 = 'Name';
$lang['job_type_tbl_hdr_actions'] 			 	 = 'Actions';
$lang['job_type_edit_fm_title']               = 'Edit job type details';
$lang['job_type_add_fm_title']                = 'Add new job type';
$lang['job_type_notif_add_success']           = 'New job type was added to the system';
$lang['job_type_notif_add_error']             = 'Something went wrong</br>The job type was not created';
$lang['job_type_notif_edit_success']          = 'Job type details successfuly updated';
$lang['job_type_notif_edit_error']            = 'Something went wrong</br>The job type was not updated';
$lang['job_type_notif_delete_success']        = 'Job type successfuly deleted';
$lang['job_type_notif_delete_error']          = 'Something went wrong</br>The job type was not deleted';
$lang['job_type_notif_load_error']          	 = 'Something went wrong trying to load the department data into the form';