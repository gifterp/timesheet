<?php
$lang['council_name']                        = 'Council';
$lang['council_sect_title']                  = 'Council List';
$lang['council_list_title']                  = 'Council list';
$lang['council_add_btn_text']                = 'Add Council';
$lang['council_edit_fm_title']               = 'Edit council details';
$lang['council_add_fm_title']                = 'Add new council';
$lang['council_fm_name_lbl']              	= 'Name';
$lang['council_fm_name_ph']  						= 'Add Name';
$lang['council_tbl_hdr_name']   				= 'Name';
$lang['council_tbl_hdr_actions'] 			= 'Actions';
$lang['council_notif_add_success']           = 'New council item was added to the system';
$lang['council_notif_add_error']             = 'Something went wrong</br>The council details were not added';
$lang['council_notif_edit_success']          = 'council details successfuly updated';
$lang['council_notif_edit_error']            = 'Something went wrong</br>The council details were not updated';
$lang['council_notif_load_error']            = 'Something went wrong trying to load the council data into the form'; 
