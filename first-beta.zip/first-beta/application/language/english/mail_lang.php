<?php
$lang['mail_name']                        = 'Mail';
$lang['mail_sect_title']                  = 'Mailing List';
$lang['mail_list_title']                  = 'Mailing list';
$lang['mail_add_btn_text']                = 'Add Mail';
$lang['mail_edit_fm_title']               = 'Edit mail details';
$lang['mail_add_fm_title']                = 'Add new mail item';
$lang['mail_tbl_hdr_id']   					= 'Id';
$lang['mail_tbl_hdr_send']   					= 'Send';	
$lang['mail_tbl_hdr_recipient']   			= 'Recipient';
$lang['mail_tbl_hdr_desc']   					= 'Description';
$lang['mail_tbl_hdr_actions'] 				= 'Actions';
$lang['mail_notif_add_success']           = 'New mail item was added to the system';
$lang['mail_notif_add_error']             = 'Something went wrong</br>The mail details were not added';
$lang['mail_notif_edit_success']          = 'Mail item details successfuly updated';
$lang['mail_notif_edit_error']            = 'Something went wrong</br>The mail details were not updated';
$lang['mail_notif_delete_success']        = 'Mail item details successfuly deleted';
$lang['mail_notif_delete_error']          = 'Something went wrong</br>The mail details were not deleted';
 