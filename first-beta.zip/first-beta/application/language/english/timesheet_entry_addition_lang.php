<?php
$lang['timesheet_entry_add_name']         			= 'Entry Addons';
$lang['timesheet_entry_add_sect_title']   			= 'Entry Addons';
$lang['timesheet_entry_add_list_title']   			= 'Entry Addons List';
$lang['timesheet_entry_add_add_btn_text']          = 'Add Entry Addons';
$lang['timesheet_entry_add_tbl_hdr_id']   			= 'Id';
$lang['timesheet_entry_add_tbl_hdr_name']   			= 'Name';
$lang['timesheet_entry_add_tbl_hdr_desc']   			= 'Description';
$lang['timesheet_entry_add_tbl_hdr_type']   			= 'Type';
$lang['timesheet_entry_add_tbl_hdr_value']   		= 'Value';
$lang['timesheet_entry_add_tbl_hdr_action']   		= 'Actions';
$lang['timesheet_entry_add_notif_add_success']     = 'New Entry Addons item was added to the system';
$lang['timesheet_entry_add_notif_add_error']       = 'Something went wrong</br>The Entry Addons details were not added';
$lang['timesheet_entry_add_notif_edit_success']    = 'Entry Addons item details successfuly updated';
$lang['timesheet_entry_add_notif_edit_error']      = 'Something went wrong</br>The Entry Addons details were not updated';
$lang['timesheet_entry_add_notif_delete_success']  = 'Entry Addons item details successfuly deleted';
$lang['timesheet_entry_add_notif_delete_error']    = 'Something went wrong</br>The Entry Addons details were not deleted';