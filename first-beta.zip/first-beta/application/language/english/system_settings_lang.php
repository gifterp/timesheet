<?php
$lang['system_settings_adm_set_name']             	= 'System Settings';
$lang['system_settings_adm_set_sect_title']        = 'System Settings Panel';
$lang['system_settings_adm_set_display_title']		= 'System Settings Appearnance';	
$lang['system_settings_adm_set_display_subtitle']  = 'These will configure the system settings';	
$lang['system_settings_adm_set_other_title']			= 'Other System Settings';	
$lang['system_settings_adm_has_cadastral_lbl']		= 'System has Cadastral';	
$lang['system_settings_adm_has_cadastral_ttip']		= 'Check if system have cadastral job';	
$lang['system_settings_adm_business_lbl']				= 'System Business Name';	
$lang['system_settings_adm_business_ttip']			= 'The business name for the system';	
$lang['system_settings_adm_job_format_lbl']			= 'System Job Name Format';	
$lang['system_settings_adm_job_format_ttip']			= 'The job format for the system';	
$lang['system_settings_adm_default_zone_lbl']		= 'System Default Zone';	
$lang['system_settings_adm_default_zone_ttip']		= 'The default zone for the system';	 
$lang['system_settings_adm_get_error']        		= 'Something went wrong</br>Could not retrieve settings from database';
$lang['system_settings_adm_update_error']        	= 'Something went wrong</br>Could not update settings in the database';
