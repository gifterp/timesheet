<?php
$lang['login_fm_username_lbl']             	= 'Username';
$lang['login_fm_username_ph']               	= 'Enter Username';
$lang['login_fm_password_lbl']             	= 'Password';
$lang['login_fm_password_ph']               	= 'Enter Password';
$lang['login_fm_remember_lbl']               = 'Remember Me';
$lang['login_footer_lbl']               		= '&copy; Copyright 2016. All Rights Reserved @ Improved Software Inc.';
