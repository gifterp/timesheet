<?php
$lang['department_name']                        = 'Department';
$lang['department_sect_title']                  = 'Department List';
$lang['department_list_title']                  = 'Department list';
$lang['department_add_btn_text']                = 'Add Department';
$lang['department_edit_fm_title']               = 'Edit department details';
$lang['department_add_fm_title']                = 'Add new department';
$lang['department_fm_name_lbl']              	= 'Name';
$lang['department_fm_name_ph']  						= 'Add Name';
$lang['department_tbl_hdr_name']   					= 'Name';
$lang['department_tbl_hdr_actions'] 				= 'Actions';
$lang['department_notif_add_success']           = 'New department item was added to the system';
$lang['department_notif_add_error']             = 'Something went wrong</br>The department details were not added';
$lang['department_notif_edit_success']          = 'department details successfuly updated';
$lang['department_notif_edit_error']            = 'Something went wrong</br>The department details were not updated';
$lang['department_notif_load_error']            = 'Something went wrong trying to load the department data into the form';
