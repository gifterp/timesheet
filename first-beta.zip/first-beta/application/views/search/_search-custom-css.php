<?php
/**
 * Advance Search Custom CSS
 *
 * @author      Gifter Poja <gifter@improvedsoftware.com.au>
 * @copyright   Copyright (c) 2016 Improved Software. <https://improvedsoftware.com.au>
 * @license     Commercial
 * @version     Release: 1.0.0
 * @since       File available since Release 1.0.0
 */
?>
      <!-- Custom CSS -->
      <link rel="stylesheet" href="<?php echo ROOT_RELATIVE_PATH; ?>assets-system/css/system.css" />
